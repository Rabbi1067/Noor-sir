package bd.edu.seu.ssb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityBasicApplication {
    
    // https://docs.google.com/document/d/1mw9CQhTrKK6iRKlrlg2FRnrvsItSqMlbJ050B9AtAL8/edit?tab=t.0

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityBasicApplication.class, args);
    }

}

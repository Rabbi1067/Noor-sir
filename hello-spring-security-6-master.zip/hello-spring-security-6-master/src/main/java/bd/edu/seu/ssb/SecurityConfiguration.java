package bd.edu.seu.ssb;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfiguration {
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
                .authorizeHttpRequests(authorizeRequests -> authorizeRequests
                        .requestMatchers("/css/**", "/scss/**", "/images/**", "/libs/**", "/js/**").permitAll()
                        .requestMatchers("/signup", "/signin").permitAll()
                        .requestMatchers("/user").hasAnyRole("USER")    // Allow only USER
                        .requestMatchers("/admin").hasAnyRole("ADMIN")  // Allow only ADMIN

                        .requestMatchers("/user") .hasAuthority("ROLE_USER")
                        .requestMatchers("/admin").hasAuthority("ROLE_ADMIN")

                        .anyRequest().authenticated() // Allow all authenticated users for other routes
                )
                .formLogin(form -> form
                        .loginPage("/signin")
                        .usernameParameter("email")
                        .passwordParameter("password")
                        .failureUrl("/login?error=true")
                        .defaultSuccessUrl("/", true) // Redirect to /home on successful login
                )
                .logout(config -> config
                        .logoutSuccessUrl("/login?logout=true") // Redirect to login page after logout
                        .invalidateHttpSession(true) // Invalidate session after logout
                        .clearAuthentication(true) // Clear authentication
                        .deleteCookies("JSESSIONID") // Delete session cookie
                        .permitAll()
                )
                .build();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) {
        return authenticationConfiguration.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(); // Secure password storage
    }
}

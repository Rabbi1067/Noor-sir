package bd.edu.seu.ssb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityBasicApplicationTests {

    @Test
    void contextLoads() {
    }

}

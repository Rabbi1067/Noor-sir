package com.sparktech.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductShopApplicationTests {

    @Test
    void contextLoads() {
    }

}
